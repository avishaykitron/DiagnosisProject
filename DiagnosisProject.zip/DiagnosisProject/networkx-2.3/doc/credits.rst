.. include:: ../CONTRIBUTORS.rst
